package smart;

public class Appsmart {
    public static void main(String[] args) {
        Smarttv smart= new Smarttv();
        smart.crearPeliculas();
        smart.mostrarPeliculas();
        smart.buscarPelicula();
    }
}
