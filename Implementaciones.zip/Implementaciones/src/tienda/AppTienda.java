package tienda;

public class AppTienda {
	public static void main(String[] args) {
		Tienda miTienda =new Tienda();
		miTienda.crearProducto();
		miTienda.mostrarCliente();
		miTienda.mostrarCatalogo();
	}
}
